function showResult(){
    for (var i = document.querySelectorAll('.parametro').length - 1; i >= 0; i--){
        parametros.push(document.querySelectorAll(".valor")[i].value);
        valores.push(parse)
    }
}